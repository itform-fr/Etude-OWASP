<?php
// test.php
session_start();
require('config.php');

// Vérification que l'utilisateur est bien 'test'
if(!isset($_SESSION['user']) || $_SESSION['user']['login'] != 'test'){
    die("Accès refusé");
}

$sql = "SELECT id, login, connections FROM users WHERE role='provider'";
$result = $conn->query($sql);
?>
<html>
<head>
    <meta charset="utf-8">
    <title>Page de test</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <style>
        /* Style pour centrer tout le contenu */
        body {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            margin: 0;
            font-family: Arial, sans-serif;
            min-height: 100vh;
            background-color: #f7f7f7;
        }

      /* Modification de la classe banner */
        .banner {
            text-align: center;
            margin: 0;
            width: 100%;
            height: 12.5vh; /* 1/8ème de la hauteur de la page (12.5% de la hauteur de la fenêtre) */
            overflow: hidden; /* Pour éviter que l'image dépasse en hauteur */
        }

        .banner img {
            width: 100%; /* L'image occupe toute la largeur */
            height: 100%; /* L'image occupe toute la hauteur de la bannière */
            object-fit: cover; /* Assure que l'image couvre toute la zone sans déformer */
        }

        h1, h2 {
            text-align: center;
        }

        p {
            text-align: center;
            margin-top: 10px;
        }

        a {
            text-decoration: none;
            color: #007BFF;
            font-weight: bold;
        }

        a:hover {
            text-decoration: underline;
        }

        /* Style pour la section principale */
        .main-content {
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            margin-top: 20px;
            width: 100%;
            max-width: 800px;
            text-align: center;
        }

        /* Style pour la table */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: center;
        }

        th {
            background-color: #007BFF;
            color: white;
        }

        /* Style pour les zones de texte */
        input[type="text"] {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
            width: 80%;
            margin-bottom: 15px;
        }

        /* Bouton de soumission */
        input[type="submit"] {
            padding: 10px 15px;
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="banner">
        <img src="images/banner_it.jpg" alt="Bannière IT">
    </div>

    <div class="main-content">
        <h1>Statistiques des Prestataires</h1>
        <table>
            <tr>
                <th>ID</th><th>Login</th><th>Nombre de connexions</th>
            </tr>
            <?php
            while($row = $result->fetch_assoc()){
                echo "<tr>";
                echo "<td>".$row['id']."</td>";
                echo "<td>".$row['login']."</td>";
                echo "<td>".$row['connections']."</td>";
                echo "</tr>";
            }
            ?>
        </table>

        <h2>Mettre à jour l'image d'un Prestataire</h2>
        <form method="post">
            <label>ID du Prestataire :</label><br>
            <input type="text" name="provider_id" required><br>
            <label>Chemin de l'image :</label><br>
            <input type="text" name="image_path" required><br>
            <input type="submit" name="update_image" value="Mettre à jour l'image">
        </form>
        <?php
        if(isset($_POST['update_image'])){
            $provider_id = $_POST['provider_id'];
            $image_path = $_POST['image_path'];
            // Aucun filtrage du chemin, vulnérabilité de type path traversal
            $destination = "images/".$provider_id."_image.jpg";
            if(copy($image_path, $destination)){
                echo "Image mise à jour";
            } else {
                echo "Erreur lors de la mise à jour de l'image";
            }
        }
        ?>
        <p><a href="presta.php">Retour</a></p>
    </div>
</body>
</html>

