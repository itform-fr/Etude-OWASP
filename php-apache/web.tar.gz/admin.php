<?php
// admin.php
session_start();
require('config.php');
// Vérification que l'utilisateur est bien l'admin
if(!isset($_SESSION['user']) || $_SESSION['user']['login'] != 'admin'){
    die("Accès refusé");
}
if (!isset($_COOKIE['auth']) || !isset($_SESSION['auth_token']) || $_COOKIE['auth'] !== $_SESSION['auth_token']) {
    die("Accès refusé");
}


?>
<html>
<head>
    <meta charset="utf-8">
    <title>Administration</title>
    <!-- <link rel="stylesheet" type="text/css" href="css/style.css"> -->
    <style>
	/* Style pour centrer tout le contenu */
	html {
	    margin: 0;
            padding: 0;
	}
        body {
            flex-direction: column;
            align-items: center;
            justify-content: center;
	    margin: 0;
	    padding: 0;
	    margin-top: 0;
            font-family: Arial, sans-serif;
            min-height: 100vh;
            background-color: #f7f7f7;
        }
      /* Modification de la classe banner */
	.banner {
	    z-index: 9999;
            text-align: center;
            margin: 0;
            width: 100%;
            height: 12.5vh; /* 1/8ème de la hauteur de la page (12.5% de la hauteur de la fenêtre) */
            overflow: hidden; /* Pour éviter que l'image dépasse en hauteur */
        }

        .banner img {
            width: 100%; /* L'image occupe toute la largeur */
            height: 100%; /* L'image occupe toute la hauteur de la bannière */
            object-fit: cover; /* Assure que l'image couvre toute la zone sans déformer */
        }

        h1, h2 {
            text-align: center;
        }

        p {
            text-align: center;
            margin-top: 10px;
        }

        a {
            text-decoration: none;
            color: #007BFF;
            font-weight: bold;
        }

        a:hover {
            text-decoration: underline;
        }

        /* Style pour la section principale */
	.main-content {
            background-color: #fff;
	    padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
	    margin-top: 20px;
	    margin-left: auto;
	    margin-right: auto;
            width: 100%;
            max-width: 800px;
            text-align: center;
        }

        /* Style pour le tableau */
        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: center;
        }

        /* Formulaire de création de prestataire */
        form {
            margin-top: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        input[type="text"] {
            margin: 5px 0;
            padding: 8px;
            width: 250px;
        }

        input[type="submit"] {
            padding: 10px 15px;
            margin-top: 10px;
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="banner">
        <img src="images/banner_it.jpg" alt="Bannière IT">
    </div>
    <div class="main-content">
        <h1>Administration des Prestataires</h1>

        <h2>Créer un Prestataire</h2>
        <form method="post">
            <label>Login :</label> <input type="text" name="login" required><br>
            <label>Mot de passe :</label> <input type="text" name="password" required><br>
            <input type="submit" name="create" value="Créer">
        </form>
	<?
	if(isset($_POST['create'])){
	    $login = $_POST['login'];
	    $password = $_POST['password'];
	    $sql1 = "SELECT * FROM users where login='$login';";
	    $result = $conn->query($sql1);
	    echo "<p style=color:green>Debug de la requête: </p><p style=color:green>" . $sql1 . "</p>";
	    if($result->num_rows > 0){
	        while($row = $result->fetch_assoc()) {
	            echo "<p>";
	            echo "<script>alert('L\'utilisateur " .  $row['login'] . " existe déjà !')</script>";
	            echo "</p>";
	        }
	    } else {
		$cv_tmp = base64_encode("CV par défaut de " . $login);
	        $sql = "INSERT INTO users (login, password, role, tarifs, cv, avatar) VALUES ('$login', '$password', 'provider', 'Tarif à la journée 0 euros', '$cv_tmp', 'avatar_default.jpg')";
	        if($conn->query($sql)){
	            echo "<script>alert('Prestataire créé')</script>";
	        } else {
	            echo "Erreur : " . $conn->error . "<br>";
	        }
	    }
	}
	?>

        <h2>Liste des Prestataires</h2>
        <table>
            <tr>
                <th>ID</th><th>Login</th><th>Action</th>
            </tr>
            <?php
            $sql = "SELECT id, login FROM users WHERE role='provider'";
            $result = $conn->query($sql);
            while($row = $result->fetch_assoc()){
                echo "<tr>";
                echo "<td>".$row['id']."</td>";
                echo "<td>".$row['login']."</td>";
                echo "<td>
                <form method='post' style='display:inline;'>
                    <input type='hidden' name='user_id' value='".$row['id']."'>
                    <input type='submit' name='delete' value='Supprimer'>
                </form>
                </td>";
                echo "</tr>";
            }
            ?>
	</table>
	<?
	if(isset($_POST['delete'])){
	    $userId = $_POST['user_id'];
	    // Requête vulnérable à l'injection SQL
	    $sql = "DELETE FROM users WHERE id='$userId'";
	    if(!in_array($userId, range(1, 5))){ 
	    	if($conn->query($sql)){
			echo "<script>alert('Prestataire supprimé');window.location.href='admin.php'</script>";
	    	} else {
	        	echo "Erreur : " . $conn->error . "<br>";
		}
	    } else {
		echo "<script>alert('Impossible de supprimer l\'utilisateur')</script>";
	    }
	}
	?>

	<p><a href="presta.php">Retour</a></p>
</body>
</html>

