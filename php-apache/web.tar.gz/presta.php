<?php
// presta.php
session_start();
if(!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
if (!isset($_COOKIE['auth']) || !isset($_SESSION['auth_token']) || $_COOKIE['auth'] !== $_SESSION['auth_token']) {
    header("Location: login.php");
    exit();
}
?>
<html>
<head>
    <meta charset="utf-8">
    <title>Plateforme Prestataires</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <style>
        /* Style pour centrer tout le contenu */
        body {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            margin: 0;
            font-family: Arial, sans-serif;
            min-height: 100vh;
            background-color: #f7f7f7;
        }

      /* Modification de la classe banner */
        .banner {
            text-align: center;
            margin: 0;
            width: 100%;
            height: 12.5vh; /* 1/8ème de la hauteur de la page (12.5% de la hauteur de la fenêtre) */
            overflow: hidden; /* Pour éviter que l'image dépasse en hauteur */
        }

        .banner img {
            width: 100%; /* L'image occupe toute la largeur */
            height: 100%; /* L'image occupe toute la hauteur de la bannière */
            object-fit: cover; /* Assure que l'image couvre toute la zone sans déformer */
        }

        h1 {
            text-align: center;
        }

        p {
            text-align: center;
            margin-top: 10px;
        }

        a {
            text-decoration: none;
            color: #007BFF;
            font-weight: bold;
        }

        a:hover {
            text-decoration: underline;
        }

        /* Style pour la section principale */
        .main-content {
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            margin-top: 20px;
            width: 100%;
            max-width: 600px;
            text-align: center;
        }

        /* Ajout d'une marge pour séparer les éléments */
        .main-content p {
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="banner">
        <img src="images/banner_it.jpg" alt="Bannière IT">
    </div>

    <div class="main-content">
        <h1>Bienvenue <?php echo $_SESSION['user']['login']; ?></h1>
        <p>Plateforme de location de services d'administration système et réseau.</p>
        <p><a href="profile.php?id=<?php echo $_SESSION['user']['id']; ?>">Modifier votre CV</a></p>

        <?php
        if($_SESSION['user']['login'] == 'admin'){
           echo '<p><a href="admin.php">Administration</a></p>';
        }
        ?>

        <p><a href="logout.php">Déconnexion</a></p>
    </div>
</body>
</html>

