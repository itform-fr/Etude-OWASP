<?php
// logout.php
session_start();
session_destroy();
setcookie("auth", "", time() - 3600, "/", "", false, true);
unset($_SESSION['auth_token']);
header("Location: index.php");
exit();
?>
