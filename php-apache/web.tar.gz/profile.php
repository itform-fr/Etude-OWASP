<?php
// profile.php
session_start();
require('config.php');

// Vérification de l'authentification
if(!isset($_SESSION['user'])){
    header("Location: login.php");
    exit();
}

if(isset($_GET['id'])){
    $id = $_GET['id'];
    // Pas de vérification que l'utilisateur a le droit de modifier ce profil
    $sql = "SELECT * FROM users WHERE id='$id'";
    $result = $conn->query($sql);
    if($result->num_rows == 0){
        die("Utilisateur non trouvé");
    }
    $userProfile = $result->fetch_assoc();
} else {
    die("Aucun utilisateur spécifié");
}

if(isset($_POST['update'])){
    $tarif = $_POST['tarif'];
    $cv = base64_encode($_POST['cv']);

    $sql = "UPDATE users SET tarifs='$tarif', cv='$cv' WHERE id='$id'";
    if($id != 4 && $id != 5 ){
	$conn->query($sql);
        header("Location: profile.php?id=" . $id);
        exit();
    } else {
        echo "Erreur : " . $conn->error;
    }
}
?>
<html>
<head>
    <meta charset="utf-8">
    <title>Modifier CV - <?php echo $userProfile['login']; ?></title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <style>
        /* Style pour centrer tout le contenu */
        body {
            flex-direction: column;
            align-items: center;
            justify-content: center;
            margin: 0;
            font-family: Arial, sans-serif;
            min-height: 100vh;
            background-color: #f7f7f7;
        }

      /* Modification de la classe banner */
        .banner {
            text-align: center;
            margin: 0;
            width: 100%;
            height: 12.5vh; /* 1/8ème de la hauteur de la page (12.5% de la hauteur de la fenêtre) */
            overflow: hidden; /* Pour éviter que l'image dépasse en hauteur */
        }

        .banner img {
            width: 100%; /* L'image occupe toute la largeur */
            height: 100%; /* L'image occupe toute la hauteur de la bannière */
            object-fit: cover; /* Assure que l'image couvre toute la zone sans déformer */
        }

        h1, h2 {
            text-align: center;
        }

        p {
            text-align: center;
            margin-top: 10px;
        }

        a {
            text-decoration: none;
            color: #007BFF;
            font-weight: bold;
        }

        a:hover {
            text-decoration: underline;
        }

        /* Style pour la section principale */
	.main-content {
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
	    margin-top: 20px;
	    margin-left: auto;
	    margin-right: auto;
	    width: 100%;
	    height: auto;
            max-width: 800px;
            text-align: center;
        }

        /* Style pour les zones de texte */
        textarea {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
            margin-bottom: 15px;
            resize: vertical;
        }

        /* Bouton de soumission */
        input[type="submit"] {
            padding: 10px 15px;
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="banner">
        <img src="images/banner_it.jpg" alt="Bannière IT">
    </div>

    <div class="main-content">
        <h1>Modifier le CV de <?php echo $userProfile['login']; ?></h1>
        <form method="post">
            <label>Tarifs :</label><br>
            <textarea name="tarif" rows="3"><?php echo $userProfile['tarifs']; ?></textarea><br>
            <label>Curriculum Vitae:</label><br>
            <textarea name="cv" rows="20"><?php echo base64_decode($userProfile['cv']); ?></textarea><br>
            <input type="submit" name="update" value="Mettre à jour">
        </form>

        <p>
            <?php
            if(isset($_POST['showDescription'])){
                echo base64_decode($userProfile['cv']);
            }
            ?>
        </p>

        <form method="post">
            <input type="submit" name="showDescription" value="Voir le CV mis en forme"/>
        </form>

        <p><a href="presta.php">Retour</a></p>
    </div>
</body>
</html>

