<?php
// login.php
session_start();
require('config.php');

if(isset($_POST['login'])) {
    $login = $_POST['login'];
    $pass = $_POST['password'];
    // Requête vulnérable à l'injection SQL (utilisez-la uniquement pour tester les failles)
    $sql = "SELECT * FROM users WHERE login='$login' AND password='$pass'";
    $result = $conn->query($sql);

    if($result && $result->num_rows > 0) {
         $user = $result->fetch_assoc();
         $_SESSION['user'] = $user;
         // Cookie d'authentification (non sécurisé)
         $authToken = bin2hex(random_bytes(32)); // Génération d'un token unique
         setcookie("auth", $authToken, time() + 3600, "/", "", false, false); // HttpOnly pour plus de sécurité
         $_SESSION['auth_token'] = $authToken;

         header("Location: presta.php");
         exit();
    } else {
         $error = "Identifiants incorrects";
    }
}
?>
<html>
<head>
    <meta charset="utf-8">
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <style>
        /* Style pour centrer tout le contenu */
        body {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            margin: 0;
            font-family: Arial, sans-serif;
            min-height: 100vh;
            background-color: #f7f7f7;
        }

      /* Modification de la classe banner */
        .banner {
            text-align: center;
            margin: 0;
            width: 100%;
            height: 12.5vh; /* 1/8ème de la hauteur de la page (12.5% de la hauteur de la fenêtre) */
            overflow: hidden; /* Pour éviter que l'image dépasse en hauteur */
        }

        .banner img {
            width: 100%; /* L'image occupe toute la largeur */
            height: 100%; /* L'image occupe toute la hauteur de la bannière */
            object-fit: cover; /* Assure que l'image couvre toute la zone sans déformer */
        }

        h1 {
            text-align: center;
        }

        /* Style du formulaire */
        form {
            display: flex;
            flex-direction: column;
            align-items: center;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            margin-top: 20px;
            width: 100%;
            max-width: 400px;
        }

        label {
            margin-bottom: 10px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="password"] {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            width: 100%;
            max-width: 300px;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            max-width: 300px;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        .error {
            color: red;
            font-size: 14px;
            margin-bottom: 20px;
        }

        p {
            margin-top: 20px;
        }

        a {
            text-decoration: none;
            color: #007BFF;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="banner">
        <img src="images/banner_it.jpg" alt="Bannière IT">
    </div>

    <h1>Connexion</h1>

    <?php if(isset($error)) echo "<p class='error'>$error</p>"; ?>

    <form method="post">
        <label>Login :</label>
        <input type="text" name="login" required />

        <label>Mot de passe :</label>
        <input type="password" name="password" required />

        <input type="submit" name="submit" value="Se connecter" />
    </form>

    <p><a href="index.php">Retour à l'accueil</a></p>
</body>
</html>

