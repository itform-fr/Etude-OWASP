<?php
// index.php
require('config.php');
?>
<html>
<head>
    <meta charset="utf-8">
    <title>Liste des Prestataires</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <style>
        /* Style pour centrer tout le contenu */
        body {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
            margin: 0;
            font-family: Arial, sans-serif;
            min-height: 100vh;
            background-color: #f7f7f7;
        }

/* Modification de la classe banner */
.banner {
    text-align: center;
    margin: 0;
    width: 100%;
    height: 12.5vh; /* 1/8ème de la hauteur de la page (12.5% de la hauteur de la fenêtre) */
    overflow: hidden; /* Pour éviter que l'image dépasse en hauteur */
}

.banner img {
    width: 100%; /* L'image occupe toute la largeur */
    height: 100%; /* L'image occupe toute la hauteur de la bannière */
    object-fit: cover; /* Assure que l'image couvre toute la zone sans déformer */
}
        h1 {
            text-align: center;
        }

        .provider-container {
            perspective: 1000px;
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: space-evenly;
            margin-top: 20px;
            padding: 20px;
            width: 100%;
            box-sizing: border-box;
        }

        .provider-card {
            width: 300px;
            height: 500px;  /* Fixed height for each card */
            transform-style: preserve-3d;
            transition: transform 0.6s;
            cursor: pointer;
            display: flex;
            flex-direction: column;
            margin: 10px;
            box-sizing: border-box;
            position: relative;
        }

        .provider-card.flipped {
            transform: rotateY(180deg);  /* Rotation de la carte */
        }

        /* Style pour la carte en plein écran */
        .provider-card.fullscreen {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100vh;
            background-color: #f4f4f4;
            z-index: 9999;
            display: flex;
            align-items: center;
            justify-content: center;
            transform: scale(1) rotateY(180deg); /* Garder la taille réelle en plein écran avec la rotation */
            transition: transform 0.6s ease-in-out;
        }

        /* Style pour le dos de la carte en plein écran */
        .provider-card.fullscreen .provider-back {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: #fff;
            padding: 30px;
            overflow-y: auto;
            transform: rotateY(180deg);
            z-index: 9999;
        }

        /* Style pour la face avant et le dos de la carte */
        .provider-front, .provider-back {
            position: absolute;
            width: 100%;
            height: 100%;
            backface-visibility: hidden;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            background-color: #f4f4f4;
            padding: 10px;
            box-sizing: border-box;
        }

        .provider-front {
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-color: #fff;
            height: 100%;
            transition: transform 0.6s;
            object-fit: cover; /* Assure que l'image couvre tout l'espace */
        }

        .provider-back {
            background-color: #f4f4f4;
            padding: 10px;
            height: 100%;
            transform: rotateY(180deg);
            overflow-y: auto;
            word-wrap: break-word;
            text-align: justify;
        }

        /* Ajustements pour le texte du CV */
        .provider-back h3 {
            margin-top: 10px;
        }

        .provider-back p {
            margin-bottom: 10px;
        }

        /* Ajustement de la taille de l'image */
        .provider-front {
            height: 60%;
        }

        .provider-back {
            height: 40%;
        }

        /* Ajout d'un conteneur pour centrer et espacer les cartes */
        .provider-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-evenly;  /* Alignement horizontal */
            gap: 20px;
        }
    </style>
</head>
<body>
    <!-- Bannière en haut de la page -->
    <div class="banner">
        <img src="images/banner_it.jpg" alt="Bannière IT">
    </div>

    <h1>Liste des Prestataires</h1>

    <div class="provider-container">
        <?php
        $sql = "SELECT id, login, tarifs, cv, avatar FROM users WHERE role='provider'";
        $result = $conn->query($sql);
        if($result && $result->num_rows > 0) {
            while($row = $result->fetch_assoc()){
                echo "<div class='provider-card' onclick='flipCard(this)'>";
                // Image par défaut pour tous les prestataires
                $avatar = isset($row['avatar']) ? $row['avatar'] : 'default_avatar.svg';
                echo "<div class='provider-front' style='background-image: url(\"images/$avatar\");'></div>"; // Image par défaut
                echo "<div class='provider-back'>";
                // Afficher la description et le CV
                echo "<p>" . base64_decode($row['cv']) . "</p>"; // Décodage base64 de la description
                echo "<p>" . $row['tarifs'] . "</p>"; // CV
                echo "</div>"; // fin de la face arrière
                echo "</div>"; // fin de la carte
            }
        }
        ?>
    </div>
    <p><a href="login.php">Se connecter</a></p>

    <script>
        function flipCard(card) {
            if (card.classList.contains('fullscreen')) {
                // Si la carte est en plein écran, revenez à l'état initial
                card.classList.remove('fullscreen');
                card.classList.remove('flipped');
            } else {
                // Si la carte n'est pas en plein écran, retournez-la et mettez-la en plein écran
                card.classList.add('flipped');
                card.classList.add('fullscreen');
            }
        }
    </script>
</body>
</html>

